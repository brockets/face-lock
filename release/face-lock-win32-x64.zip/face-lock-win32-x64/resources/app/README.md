# install

`npm install`
`./node_modules/.bin/electron-rebuild`

# dev

`npm start`

# build

`npm run build`
